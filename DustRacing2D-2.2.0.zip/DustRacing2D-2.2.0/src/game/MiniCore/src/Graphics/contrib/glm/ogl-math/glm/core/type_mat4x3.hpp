///////////////////////////////////////////////////////////////////////////////////
/// OpenGL Mathematics (glm.g-truc.net)
///
/// Copyright (c) 2005 - 2012 G-Truc Creation (www.g-truc.net)
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.
///
/// @ref core
/// @file glm/core/type_mat4x3.hpp
/// @date 2006-08-04 / 2011-06-15
/// @author Christophe Riccio
///////////////////////////////////////////////////////////////////////////////////

#ifndef glm_core_type_mat4x3
#define glm_core_type_mat4x3

#include "type_mat.hpp"

namespace glm {
namespace detail {
template<typename T>
struct tvec1;
template<typename T>
struct tvec2;
template<typename T>
struct tvec3;
template<typename T>
struct tvec4;
template<typename T>
struct tmat2x2;
template<typename T>
struct tmat2x3;
template<typename T>
struct tmat2x4;
template<typename T>
struct tmat3x2;
template<typename T>
struct tmat3x3;
template<typename T>
struct tmat3x4;
template<typename T>
struct tmat4x2;
template<typename T>
struct tmat4x3;
template<typename T>
struct tmat4x4;

// \brief Template for 4 columns and 3 rows matrix of floating-point numbers.
// \ingroup core_template
template<typename T>
struct tmat4x3
{
    enum ctor
    {
        null
    };
    typedef T value_type;
    typedef std::size_t size_type;
    typedef tvec3<T> col_type;
    typedef tvec4<T> row_type;
    GLM_FUNC_DECL size_type length() const;
    static GLM_FUNC_DECL size_type col_size();
    static GLM_FUNC_DECL size_type row_size();

    typedef tmat4x3<T> type;
    typedef tmat3x4<T> transpose_type;

private:
    // Data
    col_type value[4];

public:
    // Constructors
    GLM_FUNC_DECL tmat4x3();
    GLM_FUNC_DECL tmat4x3(tmat4x3 const & m);

    GLM_FUNC_DECL explicit tmat4x3(
      ctor Null);
    GLM_FUNC_DECL explicit tmat4x3(
      value_type const & x);
    GLM_FUNC_DECL explicit tmat4x3(
      value_type const & x0, value_type const & y0, value_type const & z0,
      value_type const & x1, value_type const & y1, value_type const & z1,
      value_type const & x2, value_type const & y2, value_type const & z2,
      value_type const & x3, value_type const & y3, value_type const & z3);
    GLM_FUNC_DECL explicit tmat4x3(
      col_type const & v0,
      col_type const & v1,
      col_type const & v2,
      col_type const & v3);

    //////////////////////////////////////
    // Conversions
    template<typename U>
    GLM_FUNC_DECL explicit tmat4x3(
      U const & x);

    template<
      typename X1, typename Y1, typename Z1,
      typename X2, typename Y2, typename Z2,
      typename X3, typename Y3, typename Z3,
      typename X4, typename Y4, typename Z4>
    GLM_FUNC_DECL explicit tmat4x3(
      X1 const & x1, Y1 const & y1, Z1 const & z1,
      X2 const & x2, Y2 const & y2, Z2 const & z2,
      X3 const & x3, Y3 const & y3, Z3 const & z3,
      X4 const & x4, Y4 const & y4, Z4 const & z4);

    template<typename V1, typename V2, typename V3, typename V4>
    GLM_FUNC_DECL explicit tmat4x3(
      tvec3<V1> const & v1,
      tvec3<V2> const & v2,
      tvec3<V3> const & v3,
      tvec3<V4> const & v4);

    // Matrix conversions
    template<typename U>
    GLM_FUNC_DECL explicit tmat4x3(tmat4x3<U> const & m);

    GLM_FUNC_DECL explicit tmat4x3(tmat2x2<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat3x3<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat4x4<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat2x3<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat3x2<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat2x4<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat4x2<T> const & x);
    GLM_FUNC_DECL explicit tmat4x3(tmat3x4<T> const & x);

    // Accesses
    col_type & operator[](size_type i);
    col_type const & operator[](size_type i) const;

    // Unary updatable operators
    GLM_FUNC_DECL tmat4x3<T> & operator=(tmat4x3<T> const & m);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator=(tmat4x3<U> const & m);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator+=(U const & s);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator+=(tmat4x3<U> const & m);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator-=(U const & s);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator-=(tmat4x3<U> const & m);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator*=(U const & s);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator*=(tmat4x3<U> const & m);
    template<typename U>
    GLM_FUNC_DECL tmat4x3<T> & operator/=(U const & s);

    GLM_FUNC_DECL tmat4x3<T> & operator++();
    GLM_FUNC_DECL tmat4x3<T> & operator--();
};

// Binary operators
template<typename T>
tmat4x3<T> operator+(
  tmat4x3<T> const & m,
  typename tmat4x3<T>::value_type const & s);

template<typename T>
tmat4x3<T> operator+(
  tmat4x3<T> const & m1,
  tmat4x3<T> const & m2);

template<typename T>
tmat4x3<T> operator-(
  tmat4x3<T> const & m,
  typename tmat4x3<T>::value_type const & s);

template<typename T>
tmat4x3<T> operator-(
  tmat4x3<T> const & m1,
  tmat4x3<T> const & m2);

template<typename T>
tmat4x3<T> operator*(
  tmat4x3<T> const & m,
  typename tmat4x3<T>::value_type const & s);

template<typename T>
tmat4x3<T> operator*(
  typename tmat4x3<T>::value_type const & s,
  tmat4x3<T> const & m);

template<typename T>
typename tmat4x3<T>::col_type operator*(
  tmat4x3<T> const & m,
  typename tmat4x3<T>::row_type const & v);

template<typename T>
typename tmat4x3<T>::row_type operator*(
  typename tmat4x3<T>::col_type const & v,
  tmat4x3<T> const & m);

template<typename T>
tmat2x3<T> operator*(
  tmat4x3<T> const & m1,
  tmat2x4<T> const & m2);

template<typename T>
tmat3x3<T> operator*(
  tmat4x3<T> const & m1,
  tmat3x4<T> const & m2);

template<typename T>
tmat4x3<T> operator*(
  tmat4x3<T> const & m1,
  tmat4x4<T> const & m2);

template<typename T>
tmat4x3<T> operator/(
  tmat4x3<T> const & m,
  typename tmat4x3<T>::value_type const & s);

template<typename T>
tmat4x3<T> operator/(
  typename tmat4x3<T>::value_type const & s,
  tmat4x3<T> const & m);

// Unary constant operators
template<typename T>
tmat4x3<T> const operator-(
  tmat4x3<T> const & m);

template<typename T>
tmat4x3<T> const operator--(
  tmat4x3<T> const & m,
  int);

template<typename T>
tmat4x3<T> const operator++(
  tmat4x3<T> const & m,
  int);

} //namespace detail

/// @addtogroup core_precision
/// @{

/// 4 columns of 3 components matrix of low precision floating-point numbers.
/// There is no guarantee on the actual precision.
///
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.1.6 Matrices</a>
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.7.2 Precision Qualifier</a>
typedef detail::tmat4x3<lowp_float> lowp_mat4x3;

/// 4 columns of 3 components matrix of medium precision floating-point numbers.
/// There is no guarantee on the actual precision.
///
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.1.6 Matrices</a>
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.7.2 Precision Qualifier</a>
typedef detail::tmat4x3<mediump_float> mediump_mat4x3;

/// 4 columns of 3 components matrix of high precision floating-point numbers.
/// There is no guarantee on the actual precision.
///
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.1.6 Matrices</a>
/// @see <a href="http://www.opengl.org/registry/doc/GLSLangSpec.4.20.8.pdf">GLSL 4.20.8 specification, section 4.7.2 Precision Qualifier</a>
typedef detail::tmat4x3<highp_float> highp_mat4x3;

/// @}
} //namespace glm

#ifndef GLM_EXTERNAL_TEMPLATE
#include "type_mat4x3.inl"
#endif //GLM_EXTERNAL_TEMPLATE

#endif //glm_core_type_mat4x3
